'use strict';

const dev = require('./Dev');
const dist = require('./Dist');

module.exports = {
  dev,
  dist
};
